﻿using System.Collections;
using System.Collections.Generic;
using DWP2.WaterEffects;
using UnityEditor;
using UnityEngine;

namespace DWP2
{
    public class WaterObjectWizard : MonoBehaviour
    {
        public bool addWaterParticleSystem;
    }
}