﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

#if DWP_CREST
using Crest;
#endif

namespace DWP2
{
    public class FlatWaterDataProvider : WaterDataProvider
    {
    }
}

