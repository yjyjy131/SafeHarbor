using System;
using UnityEngine;

namespace DefaultWater
{
    [ExecuteInEditMode]
    [RequireComponent(typeof(WaterBase))]
    public class GerstnerDisplace : Displace { }
}